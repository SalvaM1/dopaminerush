Modelo Banco Parque: "Park Bench- Banco de parque" (https://skfb.ly/oGuEu) by darineroar is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
